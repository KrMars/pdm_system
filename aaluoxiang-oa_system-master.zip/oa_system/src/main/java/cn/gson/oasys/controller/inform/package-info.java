
/**
 * 通知管理
 * @author luoxiang
 *
 */
package cn.gson.oasys.controller.inform;