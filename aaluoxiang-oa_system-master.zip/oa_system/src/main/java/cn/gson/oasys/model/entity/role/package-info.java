/**
 * 
 */
/**角色权限
 * @author 宋妈
 *
 */
package cn.gson.oasys.model.entity.role;