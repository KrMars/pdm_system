
/**
 * 通知公告service
 * @author luoxiang
 *
 */
package cn.gson.oasys.services.inform;