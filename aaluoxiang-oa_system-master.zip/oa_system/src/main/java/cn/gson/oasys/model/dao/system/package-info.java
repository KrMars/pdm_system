
/**
 * 系统管理的dao
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.dao.system;